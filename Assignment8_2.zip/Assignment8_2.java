import java.util.Scanner;
public class Assignment8_2 {

	

	@SuppressWarnings("resource")
	    public static void main(String[]args){

	      Scanner age = new Scanner (System.in);
	      System.out.println("Enter your age"); //Input age
	      int a = age.nextInt();
	      System.out.println("Enter you name"); //Input name
	      String b = age.next();

	  try{  
	     if(a<0){       //Throw exception if age is negative  
	        throw new NegativeAgeException();
	     }          
	    }
	    catch(NegativeAgeException ex){
	    System.out.println("You entered an invalid number " + a);        
	    }
	    finally{
	        System.out.println("Your age is " + a);
	        System.out.println("Your name is " + b);
	    }   
	}
	}
