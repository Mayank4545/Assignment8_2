
public class NegativeAgeException extends Exception {

	public void AgeExcpt(){     
        System.out.println("The Age you've entered is not valid");       
	}
}
